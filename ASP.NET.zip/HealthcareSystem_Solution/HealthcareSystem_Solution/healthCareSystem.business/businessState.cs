﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using healthCareSystem.data;

namespace healthCareSystem.business
{
    public class businessState
    {

        #region "Variable Declaration"

        DataSet stateDs = null;
        string getQuery = string.Empty;

        dalState dalObj = new dalState();

        #endregion

        #region "Object Initialization"
        int rowCount = 0;
        #endregion

        #region "Get Details"
        public DataSet GetStateDetails()
        {
            stateDs = dalObj.GetStateDetails();
            return stateDs;

        }
        #endregion

        #region "Add Details"
        public int AddStateDetails(string stateName)
        {
            try
            {
                rowCount = dalObj.AddStateDetails(stateName);
                return rowCount;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion
    }
}
