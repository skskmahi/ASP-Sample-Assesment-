﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using healthCareSystem.business;
using log4net;
using System.Web.Security;
using System.Configuration;


namespace healthCareSystem.Login
{
    public partial class loginForm : System.Web.UI.Page
    {

        // Object initialization
        #region "Object Initialization"
        businessPhysician businessObjEmp = new businessPhysician(); 
        businessDepartmentDetails businessObj = new businessDepartmentDetails();
        private static ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }

        // Authenticate User
        protected void LoginControl_Authenticate(object sender, AuthenticateEventArgs e)
        {
            try
            {
               
                if (Membership.ValidateUser(LoginControl.UserName, LoginControl.Password))
                {
                    string[] roles =  Roles.GetRolesForUser(LoginControl.UserName);
                    SetFormAuthenticationTicket(LoginControl.UserName, roles[0]);

                    // Casestudy Implementation here 
                    Session["UserName"] = LoginControl.UserName.Trim().ToString();
                    Session["UserRole"] = roles[0];

                    if (roles[0] == ConfigurationManager.AppSettings["admin"])
                    {
                        Response.Redirect("~/Admin/addPhysician.aspx", false);
                    }
                }
            
            }
            catch (Exception ex)
            {
                logger.Error("Exception occurred during Authentication for the user " + ex.Message);
                logger.Error("Exception occurred during Authentication for the user " + Server.GetLastError());
                Session["CurrentError"] = "Error occured during Authentication for the user " + LoginControl.UserName.ToString();
            }
        }


        public void SetFormAuthenticationTicket(string userName, string roleName)
        {
            FormsAuthentication.Initialize();
            FormsAuthenticationTicket Authticket = new FormsAuthenticationTicket(1,
                                                    userName,
                                                    DateTime.Now,
                                                    DateTime.Now.AddMinutes(30),
                                                    false, // Do not remember me
                                                    roleName,
                                                    FormsAuthentication.FormsCookiePath);

            string hash = FormsAuthentication.Encrypt(Authticket);

            HttpCookie Authcookie = new HttpCookie(FormsAuthentication.FormsCookieName, hash);
            if (Authticket.IsPersistent) Authcookie.Expires = Authticket.Expiration;
            Response.Cookies.Add(Authcookie);
        }

    }
}