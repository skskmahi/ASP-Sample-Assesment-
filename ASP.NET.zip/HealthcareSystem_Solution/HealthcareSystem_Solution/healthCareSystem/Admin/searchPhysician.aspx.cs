﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using healthCareSystem.business;
using System.Data;
using log4net;
using System.Configuration;

namespace healthCareSystem.Admin
{
    public partial class searchPhysician : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
        businessPhysician businessObj = new businessPhysician();
        
        private static ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #endregion
        
        // Variable Declaration
        #region "Variable Declaration"
        DataSet physicianDs, departmentDs;
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.User.IsInRole(ConfigurationManager.AppSettings["admin"]))
            {
                if (!Page.IsPostBack)
                {
                    messageLabel.Text = String.Empty;

                    DataList1.DataSource = null;
                    DataList1.DataBind();

                    BindDepartmentDetails();
                }
            }
            else
            {
                Response.Redirect("~/ErrorPage/customErrorPage.aspx", false);
            }
        }


        // Fetch department data from DB and display in the grid
        #region "Bind Department Details"
        public void BindDepartmentDetails()
        {
            logger.Debug("Binding the department details to the dropdownlist");

            departmentDs = new DataSet();
            departmentDs = businessObj.GetDepartmentDetails();


            departmentDropdownList.DataTextField = departmentDs.Tables[0].Columns["DeptName"].ToString();
            departmentDropdownList.DataValueField = departmentDs.Tables[0].Columns["DeptId"].ToString();

            departmentDropdownList.DataSource = departmentDs.Tables[0];
            departmentDropdownList.DataBind();

            departmentDropdownList.Items.Insert(0, new ListItem(" <-- Select -->", "0"));

            logger.Debug("Department details mapped to the dropdownlist successfully");


        }
        #endregion

        protected void searchButton_Click(object sender, EventArgs e)
        {
            string firstname = nameTextBox.Text.Trim();
            if (departmentDropdownList.SelectedIndex == 0 && firstname == string.Empty)
            {
                messageLabel.Text = "Please enter some search criteria and proceed !";
            }
            else 
            {

                if (firstname == string.Empty)
                    firstname = "#";

                physicianDs = businessObj.SearchPhysicianDetails(firstname, departmentDropdownList.SelectedValue);
                if (physicianDs.Tables[0].Rows.Count > 0)
                {
                messageLabel.Text = "";

                DataList1.DataSource = physicianDs;
                DataList1.DataBind();

                logger.Debug("Physician details mapped to the Grid successfully.");
                }
                else
                {
                    DataList1.DataSource = null;
                    DataList1.DataBind();

                messageLabel.Text = "No records returned for given search criteria.";
                nameTextBox.Text = string.Empty;
                departmentDropdownList.SelectedIndex = 0;
                } 
            }
        }

    
    }
}