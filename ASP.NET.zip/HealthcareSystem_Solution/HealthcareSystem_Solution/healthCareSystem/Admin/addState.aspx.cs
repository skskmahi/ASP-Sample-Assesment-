﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using healthCareSystem.business;
using log4net;
using System.Configuration;

namespace healthCareSystem.Admin
{
    public partial class addState : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
        businessState businessObj = new businessState();
        private static ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #endregion

        // Variable Declaration
        #region "Variable Declaration"
        DataSet departmentDataSet;
        int getRowCount;
        #endregion

        // Page load
        #region "Page Load"
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.User.IsInRole(ConfigurationManager.AppSettings["admin"]))
            {
                if (!Page.IsPostBack)
                {
                    BindData();
                    messageLabel.Text = String.Empty;
                }
            }
            else
            {
                Response.Redirect("~/ErrorPage/customErrorPage.aspx", false);
            }
        }
        #endregion "Page Load"

        // Fetch department data from DB and display in the grid
        #region "Bind Grid Details"
        public void BindData()
        {
           // logManager.CreateLogFile("::AddDepartment.aspx:: Binding Department Details to the Gridview");
            logger.Debug("Binding State Details to the Gridview..");
           
            departmentDataSet = new DataSet();
            departmentDataSet = businessObj.GetStateDetails();
            stateGridView.DataSource = departmentDataSet;
            stateGridView.DataBind();
            logger.Debug("Department Details mapped to Gridview successfully.");
            
          
        }
        #endregion

  
       
        // Update DB with the new Department details and display the grid
        protected void addStateButton_Click(object sender, EventArgs e)
        {
            logger.Debug("Adding State Details");
            getRowCount = businessObj.AddStateDetails(nameTextBox.Text.Trim());
            stateGridView.EditIndex = -1;
            stateGridView.ShowFooter = false;
            BindData();
            nameTextBox.Text = String.Empty;
            messageLabel.Text = "State Details added successfully!...";
            logger.Debug("State Details added successfully.No of records impacted are " + getRowCount.ToString());
        }
         
    }
}
