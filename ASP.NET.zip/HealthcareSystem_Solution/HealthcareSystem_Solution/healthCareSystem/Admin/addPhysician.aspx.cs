﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using healthCareSystem.business;
using System.Data;
using log4net;
using System.Configuration;
using System.Web.Security;
using System.Security.Principal;
using System.Threading;

namespace healthCareSystem.Admin
{
    public partial class addPhysician : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
      
        businessPhysician businessObj = new businessPhysician();
        businessState stateObj = new businessState();
        private static ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        #endregion

        // Variable Declaration
        #region "Variable Declaration"
        DataSet physicianDs, departmentDataSet;
        int getRowCount;
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.User.IsInRole(ConfigurationManager.AppSettings["admin"]))
            {
                if (!Page.IsPostBack)
                {
                    BindPhysicianDetails();
                    messageLabel.Text = String.Empty;
                    BindDepartmentDetails();
                    BindStateDetails();
                }
                this.firstNameTextBox.Focus();
            }
            else
            {
                Response.Redirect("~/ErrorPage/customErrorPage.aspx", false);
            }
        }

        // Casestudy Implementation here
        public override void VerifyRenderingInServerForm(Control control)
        {
            //base.VerifyRenderingInServerForm(control);
        }

        // Fetch Employee data from DB and display in the grid
        #region "Bind Grid Details"
        public void BindPhysicianDetails()
        {
            logger.Debug("Binding the Employee details to the GridView ");
            physicianDs = businessObj.GetPhysicianDetails();
            PhysicianGridView.DataSource = physicianDs;
            PhysicianGridView.DataBind();
            logger.Debug("Physician details mapped to the Gridview successfully.");
          
        }
        #endregion

        // Fetch DEpartment data from DB and display in the grid
        #region "Bind Department Details"
        public void BindDepartmentDetails()
        {
            logger.Debug("Binding the department details to the dropdownlist");

            departmentDataSet = businessObj.GetDepartmentDetails();

            departmentDropdownList.DataTextField = departmentDataSet.Tables[0].Columns["DeptName"].ToString();
            departmentDropdownList.DataValueField = departmentDataSet.Tables[0].Columns["DeptId"].ToString();

            departmentDropdownList.DataSource = departmentDataSet.Tables[0];
            departmentDropdownList.DataBind();

            departmentDropdownList.Items.Insert(0, new ListItem(" <-- Select -->", "0"));


            logger.Debug("Department details mapped to the dropdownlist successfully");
          
           
        }
        #endregion

        #region "Bind State Details"
        public void BindStateDetails()
        {
            logger.Debug("Binding the state details to the dropdownlist");

            DataSet ds = stateObj.GetStateDetails();

            stateDropDownList.DataTextField = ds.Tables[0].Columns["Name"].ToString();
            stateDropDownList.DataValueField = ds.Tables[0].Columns["StateId"].ToString();

            stateDropDownList.DataSource = ds.Tables[0];
            stateDropDownList.DataBind();

            stateDropDownList.Items.Insert(0, new ListItem(" <-- Select -->", "0"));


            logger.Debug("State details mapped to the dropdownlist successfully");


        }
        #endregion
             

        protected void addButton_Click(object sender, EventArgs e) //string education, string yrsofExp, string state
        {

            logger.Debug("Adding the Physician details....");
            if (departmentDropdownList.SelectedIndex > 0)
            {
                getRowCount = businessObj.AddPhysicianDetails(firstNameTextBox.Text.Trim(), lastNameTextBox.Text.Trim(), emailTextBox.Text.Trim(), phoneTextBox.Text.Trim(), departmentDropdownList.Text, eduDropDownList.SelectedValue.ToString(), expTextBox.Text.Trim(), stateDropDownList.Text);
                    PhysicianGridView.EditIndex = -1;
                    PhysicianGridView.ShowFooter = false;
                    BindPhysicianDetails();
                    firstNameTextBox.Text = String.Empty;
                    lastNameTextBox.Text = String.Empty;
                     emailTextBox.Text = String.Empty;
                    phoneTextBox.Text = String.Empty;
                    messageLabel.Text = "Physician Details added successfully!...";
                    logger.Debug("Physician details added successfully....No of records impacted are " + getRowCount.ToString());
            }
            else
            {
                dropdownlistMessageLabel.Text = "Please select valid department name and proceed.";
                logger.Warn(" Update failed. Please enter the department name and retry.");
            }
        }

        protected void PhysicianGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            PhysicianGridView.EditIndex = -1;
            BindPhysicianDetails();
            messageLabel.Text = String.Empty;
        }

        protected void PhysicianGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            logger.Debug("Deleting the Physician details");

            GridViewRow _row = PhysicianGridView.Rows[e.RowIndex];
            Label lblPhyId = (Label)_row.FindControl("lblPhyId");

            getRowCount = businessObj.DeletePhysicianDetails(lblPhyId.Text.Trim());
            PhysicianGridView.EditIndex = -1;
            BindPhysicianDetails();
            messageLabel.Text = "Physician Details deleted successfully!...";
        }

        protected void PhysicianGridView_RowEditing(object sender, GridViewEditEventArgs e)
        {
            logger.Debug("Editing the Physician details...");
            PhysicianGridView.EditIndex = e.NewEditIndex;
            BindPhysicianDetails();
            messageLabel.Text = String.Empty;
        }

        protected void PhysicianGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            logger.Debug(" Updating the Physician details");

            GridViewRow _row = PhysicianGridView.Rows[e.RowIndex];
            TextBox emailTextBox = (TextBox)_row.FindControl("emailTextBox");
            TextBox phoneTextBox = (TextBox)_row.FindControl("phoneTextBox");
            TextBox yrsTextbox = (TextBox)_row.FindControl("yrsTextbox");
            Label lblPhyId = (Label)_row.FindControl("lblPhyId");

            getRowCount = businessObj.UpdatePhysicianDetails(lblPhyId.Text.Trim(), emailTextBox.Text.Trim(), phoneTextBox.Text.Trim(), yrsTextbox.Text.Trim());
            PhysicianGridView.EditIndex = -1;
            BindPhysicianDetails();
            messageLabel.Text = "Physician Details updated successfully!...";
            logger.Debug(" Physician details updated successfully.No of records impacted are " + getRowCount.ToString());
        }

        

    }
}
