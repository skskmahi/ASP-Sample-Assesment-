﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using healthCareSystem.common;
using System.Data.SqlClient;

namespace healthCareSystem.data
{
   public class dalState
    {

        #region "Get State Details"
        public DataSet GetStateDetails()
        {
            try
            {
                DataSet ds = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetStateDetails");
                return ds;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion


        #region "Add State Details"
        public int AddStateDetails(string stateName)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@stateName", stateName);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;

                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "AddStateDetails", sqlParams);
                return rowCount;

            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion
    }
}
