USE master
IF EXISTS(select * from sys.databases where name='HealthCareDB')
DROP DATABASE HealthCareDB
go 
Create Database HealthCareDB
go