﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using healthCareSystem.business;
using System.Data;
using System.Configuration;

namespace healthCareSystem.Admin
{
    public partial class searchPhysician : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
        businessPhysician businessObj = new businessPhysician();
        #endregion
        
        // Variable Declaration
        #region "Variable Declaration"
        DataSet physicianDs, departmentDs;
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
              if (!Page.IsPostBack)
                {
                    messageLabel.Text = String.Empty;
                    searchResultsGridView.DataSource = null;
                    searchResultsGridView.DataBind();
                    BindDepartmentDetails();
                }
        }


        // Fetch department data from DB and display in the grid
        #region "Bind Department Details"
        public void BindDepartmentDetails()
        {
            departmentDs = new DataSet();
            departmentDs = businessObj.GetDepartmentDetails();


            departmentDropdownList.DataTextField = departmentDs.Tables[0].Columns["DeptName"].ToString();
            departmentDropdownList.DataValueField = departmentDs.Tables[0].Columns["DeptId"].ToString();

            departmentDropdownList.DataSource = departmentDs.Tables[0];
            departmentDropdownList.DataBind();

            departmentDropdownList.Items.Insert(0, new ListItem(" <-- Select -->", "0"));
        }
        #endregion

        protected void searchButton_Click(object sender, EventArgs e)
        {
            string firstname = nameTextBox.Text.Trim();
            if (departmentDropdownList.SelectedIndex == 0 && firstname == string.Empty)
            {
                messageLabel.Text = "Please enter some search criteria and proceed !";
            }
            else 
            {

                if (firstname == string.Empty)
                    firstname = "#";

                physicianDs = businessObj.SearchPhysicianDetails(firstname, departmentDropdownList.SelectedValue);
                if (physicianDs.Tables[0].Rows.Count > 0)
                {
                messageLabel.Text = "";
                searchResultsGridView.DataSource = physicianDs;
                searchResultsGridView.DataBind();

                }
                else
                {
                    searchResultsGridView.DataSource = null;
                    searchResultsGridView.DataBind();

                messageLabel.Text = "No records returned for given search criteria.";
                nameTextBox.Text = string.Empty;
                departmentDropdownList.SelectedIndex = 0;
                } 
            }
        }

    
    }
}