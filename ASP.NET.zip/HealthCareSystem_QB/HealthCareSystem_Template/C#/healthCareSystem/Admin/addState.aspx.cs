﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using healthCareSystem.business;
using System.Configuration;

namespace healthCareSystem.Admin
{
    public partial class addState : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
        businessState businessObj = new businessState();
        #endregion

        // Variable Declaration
        #region "Variable Declaration"
        DataSet stateDs;
        #endregion

        // Page load
        #region "Page Load"
        protected void Page_Load(object sender, EventArgs e)
        {
              if (!Page.IsPostBack)
                {
                    BindData();
                    messageLabel.Text = String.Empty;
                }
        }
         
        #endregion "Page Load"

        // Fetch state data from DB and display in the grid
        #region "Bind Grid Details"
        public void BindData()
        {
            stateDs = new DataSet();
            stateDs = businessObj.GetStateDetails();
            stateGridView.DataSource = stateDs;
            stateGridView.DataBind();
        }
        #endregion

  
       
        // Update DB with the new state details and display the grid
        protected void addStateButton_Click(object sender, EventArgs e)
        {
            //Please do the casestudy implementation here
        }

        
                
    }
}
