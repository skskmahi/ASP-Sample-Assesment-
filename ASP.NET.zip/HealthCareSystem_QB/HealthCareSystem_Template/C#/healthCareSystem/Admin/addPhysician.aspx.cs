﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using healthCareSystem.business;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Security.Principal;
using System.Threading;

namespace healthCareSystem.Admin
{
    public partial class addPhysician : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
      
        businessPhysician businessObj = new businessPhysician();
        businessState stateObj = new businessState();
        #endregion

        // Variable Declaration
        #region "Variable Declaration"
        DataSet physicianDs, departmentDataSet;
        int getRowCount;
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
              if (!Page.IsPostBack)
                {
                    BindPhysicianDetails();
                    messageLabel.Text = String.Empty;
                    BindDepartmentDetails();
                    BindStateDetails();
                }
                this.firstNameTextBox.Focus();
         }

        // Casestudy Implementation here
        public override void VerifyRenderingInServerForm(Control control)
        {
            //base.VerifyRenderingInServerForm(control);
        }

        // Fetch Employee data from DB and display in the grid
        #region "Bind Grid Details"
        public void BindPhysicianDetails()
        {
            
            physicianDs = businessObj.GetPhysicianDetails();
            PhysicianGridView.DataSource = physicianDs;
            PhysicianGridView.DataBind();
                      
        }
        #endregion

        // Fetch DEpartment data from DB and display in the grid
        #region "Bind Department Details"
        public void BindDepartmentDetails()
        {
            departmentDataSet = businessObj.GetDepartmentDetails();

            departmentDropdownList.DataTextField = departmentDataSet.Tables[0].Columns["DeptName"].ToString();
            departmentDropdownList.DataValueField = departmentDataSet.Tables[0].Columns["DeptId"].ToString();

            departmentDropdownList.DataSource = departmentDataSet.Tables[0];
            departmentDropdownList.DataBind();

            departmentDropdownList.Items.Insert(0, new ListItem(" <-- Select -->", "0"));
                     
        }
        #endregion

        #region "Bind State Details"
        public void BindStateDetails()
        {
            DataSet ds = stateObj.GetStateDetails();

            stateDropDownList.DataTextField = ds.Tables[0].Columns["Name"].ToString();
            stateDropDownList.DataValueField = ds.Tables[0].Columns["StateId"].ToString();

            stateDropDownList.DataSource = ds.Tables[0];
            stateDropDownList.DataBind();

            stateDropDownList.Items.Insert(0, new ListItem(" <-- Select -->", "0"));
         }
        #endregion
             

        protected void addButton_Click(object sender, EventArgs e) //string education, string yrsofExp, string state
        {

            if (departmentDropdownList.SelectedIndex > 0)
            {
                getRowCount = businessObj.AddPhysicianDetails(firstNameTextBox.Text.Trim(), lastNameTextBox.Text.Trim(), emailTextBox.Text.Trim(), phoneTextBox.Text.Trim(), departmentDropdownList.Text, eduDropDownList.SelectedValue.ToString(), expTextBox.Text.Trim(), stateDropDownList.Text);
                    PhysicianGridView.EditIndex = -1;
                    PhysicianGridView.ShowFooter = false;
                    BindPhysicianDetails();
                    firstNameTextBox.Text = String.Empty;
                    lastNameTextBox.Text = String.Empty;
                     emailTextBox.Text = String.Empty;
                    phoneTextBox.Text = String.Empty;
                    messageLabel.Text = "Physician Details added successfully!...";
            }
            else
            {
                dropdownlistMessageLabel.Text = "Please select valid department name and proceed.";
            }
        }

        protected void PhysicianGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            PhysicianGridView.EditIndex = -1;
            BindPhysicianDetails();
            messageLabel.Text = String.Empty;
        }

        protected void PhysicianGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            GridViewRow _row = PhysicianGridView.Rows[e.RowIndex];
            Label lblPhyId = (Label)_row.FindControl("lblPhyId");

            getRowCount = businessObj.DeletePhysicianDetails(lblPhyId.Text.Trim());
            PhysicianGridView.EditIndex = -1;
            BindPhysicianDetails();
            messageLabel.Text = "Physician Details deleted successfully!...";
        }

        protected void PhysicianGridView_RowEditing(object sender, GridViewEditEventArgs e)
        {
            PhysicianGridView.EditIndex = e.NewEditIndex;
            BindPhysicianDetails();
            messageLabel.Text = String.Empty;
        }

        protected void PhysicianGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow _row = PhysicianGridView.Rows[e.RowIndex];
            TextBox emailTextBox = (TextBox)_row.FindControl("emailTextBox");
            TextBox phoneTextBox = (TextBox)_row.FindControl("phoneTextBox");
            TextBox yrsTextbox = (TextBox)_row.FindControl("yrsTextbox");
            Label lblPhyId = (Label)_row.FindControl("lblPhyId");

            getRowCount = businessObj.UpdatePhysicianDetails(lblPhyId.Text.Trim(), emailTextBox.Text.Trim(), phoneTextBox.Text.Trim(), yrsTextbox.Text.Trim());
            PhysicianGridView.EditIndex = -1;
            BindPhysicianDetails();
            messageLabel.Text = "Physician Details updated successfully!...";
        }

        

    }
}
