﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Routing;

namespace healthCareSystem.ErrorPage
{
    public partial class customErrorPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var parameters = new RouteValueDictionary { };
            VirtualPathData vpd = RouteTable.Routes.GetVirtualPath(null, "Login", parameters);
            loginPageHyperLink.NavigateUrl = vpd.VirtualPath;
        }
    }
}