﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Linq;
using System.Configuration;

namespace healthCareSystem.Login
{
    public class User
    {
        private Table<UserObj> usersTable;
        private DataContext context;

        public User()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            context = new DataContext(connectionString);
            usersTable = context.GetTable<UserObj>();
        }

        public UserObj GetUserObjByUserName(string userName, string passWord)
        {
            UserObj user = usersTable.FirstOrDefault(u => u.UserName == userName && u.Password == passWord);
            return user;
        }

        public UserObj GetUserObjByUserName(string userName)
        {
            UserObj user = usersTable.SingleOrDefault(u => u.UserName == userName);
            return user;
        }

        public IEnumerable<UserObj> GetAllUsers()
        {
            return usersTable.AsEnumerable();
        }

        public bool IsUserInRole(String userName, string userRole)
        {
            var user = usersTable.SingleOrDefault(u => u.UserName == userName);
            if (user == null)
                return false;
            if (user.RoleName == userRole)
                return true;
            else
                return false;
        }

        public string[] GetUserRoles(String userName)
        {
            var user = usersTable.SingleOrDefault(u => u.UserName == userName);
            if (user == null)
                return new string[] { };
            if (user.RoleName == null)
                return new string[] { };
            else
            {
                String[] roleNames = new String[5];
                roleNames[0] = user.RoleName;
                return roleNames;
            }

        }

    }
}