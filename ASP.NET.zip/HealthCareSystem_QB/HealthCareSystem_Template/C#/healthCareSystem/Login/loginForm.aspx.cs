﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using healthCareSystem.business;
using System.Web.Security;
using System.Configuration;


namespace healthCareSystem.Login
{
    public partial class loginForm : System.Web.UI.Page
    {

        // Object initialization
        #region "Object Initialization"
        businessPhysician businessObjEmp = new businessPhysician(); 
        businessDepartmentDetails businessObj = new businessDepartmentDetails();
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }

        // Authenticate User
        protected void LoginControl_Authenticate(object sender, AuthenticateEventArgs e)
        {
            try
            {
               
                if (true) // Please do the implementation for Authentication 
                {
                    string roleName  = string.Empty; // Please do the implementation for Authorization.
                    SetFormAuthenticationTicket(LoginControl.UserName, roleName);
                 }            
            }
            catch (Exception ex)
            {
                   Session["CurrentError"] = "Error occured during Authentication for the user " + LoginControl.UserName.ToString();
            }
        }


        public void SetFormAuthenticationTicket(string userName, string roleName)
        {
            FormsAuthentication.Initialize();
            FormsAuthenticationTicket Authticket = new FormsAuthenticationTicket(1,
                                                    userName,
                                                    DateTime.Now,
                                                    DateTime.Now.AddMinutes(30),
                                                    false, // Do not remember me
                                                    roleName,
                                                    FormsAuthentication.FormsCookiePath);

            string hash = FormsAuthentication.Encrypt(Authticket);

            HttpCookie Authcookie = new HttpCookie(FormsAuthentication.FormsCookieName, hash);
            if (Authticket.IsPersistent) Authcookie.Expires = Authticket.Expiration;
            Response.Cookies.Add(Authcookie);
        }

    }
}