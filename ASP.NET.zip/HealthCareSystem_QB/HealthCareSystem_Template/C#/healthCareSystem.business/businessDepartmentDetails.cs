﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using healthCareSystem.data;


namespace healthCareSystem.business
{
    public class businessDepartmentDetails
    {
        #region "Variable Declaration"

        DataSet departmentDataSet = null;
        string getQuery = string.Empty;

        dalDepartmentDetails dalDepartmentObj = new dalDepartmentDetails();

        #endregion

        #region "Object Initialization"
        int rowCount = 0;
        #endregion

        #region "Get Details"
        public DataSet GetDepartmentDetails()
        {
            departmentDataSet = dalDepartmentObj.GetDepartmentDetails();
            return departmentDataSet;

        }
        #endregion

        #region "Add Details"
        public int AddDepartmentDetails(string deptName)
        {
            try
            {
                rowCount = dalDepartmentObj.AddDepartmentDetails(deptName);
                return rowCount;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region "Delete Details"
        public int DeleteDepartmentDetails(string deptId)
        {
            try
            {
                rowCount = dalDepartmentObj.DeleteDepartmentDetails(deptId);
                return rowCount;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

   }
}
