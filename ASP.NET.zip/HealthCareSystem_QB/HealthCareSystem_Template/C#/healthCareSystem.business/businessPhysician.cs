﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using healthCareSystem.data;
using System.Data;


namespace healthCareSystem.business
{
   public class businessPhysician
    {
        #region "Variable Declaration"
            string getQuery = string.Empty;
            int rowCount = 0;
            dalDepartmentDetails dalDepartmentObj = new dalDepartmentDetails();
            dalPhysicianDetails dalPhysicianObj = new dalPhysicianDetails();
        #endregion
             
        #region "Get Drop Downlist Bind Details"
        public DataSet GetDepartmentDetails()
        {

            DataSet departmentDataSet = dalDepartmentObj.GetDepartmentDetails();
            return departmentDataSet;

        }
        #endregion

        #region "Get Physician Details"
        public DataSet GetPhysicianDetails()
        {
            DataSet physicianDs = dalPhysicianObj.GetPhysicianDetails();
            return physicianDs;

        }

        #endregion

        #region "Search Physician Details"
        public DataSet SearchPhysicianDetails(string firstName, string deptId)
        {
            DataSet physicianDs = dalPhysicianObj.SearchPhysicianDetails(firstName, deptId);
            return physicianDs;

        }

        #endregion
            

        #region "Add Details"
        public int AddPhysicianDetails(string firstName, string lastName, string email, string phoneNo, string deptId, string education, string yrsofExp, string state)
        {
            try
            {
                rowCount = dalPhysicianObj.AddPhysicianDetails(firstName, lastName, email, phoneNo, deptId, education, yrsofExp, state);
                return rowCount;
            }
            catch (Exception)
            {
               
                throw;
            }
        }
        #endregion

        #region "Update Details"
        public int UpdatePhysicianDetails(string phyId, string email, string phoneNo, string yrsOfExp)
        {
            try
            {
                rowCount = dalPhysicianObj.UpdatePhysicianDetails(phyId, email, phoneNo, yrsOfExp);
                return rowCount;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        #endregion

        #region "Delete Details"
        public int DeletePhysicianDetails(string phyId)
        {
            try
            {
                rowCount = dalPhysicianObj.DeletePhysicianDetails(phyId);
                return rowCount;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        #endregion

    }
}
