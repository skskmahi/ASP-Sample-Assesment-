﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;
using System.Data.SqlClient;
using healthCareSystem.common;

namespace healthCareSystem.data
{
    public class dalPhysicianDetails
    {
        #region "Get Physician Details"
        public DataSet GetPhysicianDetails()
        {
            try
            {
                DataSet ds = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetPhysicianDetails");
                return ds;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion

        #region "Get Physician Details"
        public DataSet SearchPhysicianDetails(string firstName, string deptId)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@firstName", firstName);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;
                sqlParams[1] = new SqlParameter("@deptid", deptId);
                sqlParams[1].SqlDbType = SqlDbType.VarChar;
                DataSet ds = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "SearchPhysicianDetails", sqlParams);
                return ds;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion


        #region "Add Physician Details"
        public int AddPhysicianDetails(string firstName, string lastName, string email, string phoneNo, string deptId, string education, string yrsofExp, string state)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[8];
                sqlParams[0] = new SqlParameter("@firstName", firstName);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;
                sqlParams[1] = new SqlParameter("@lastName", lastName);
                sqlParams[1].SqlDbType = SqlDbType.VarChar;
                sqlParams[2] = new SqlParameter("@email", email);
                sqlParams[2].SqlDbType = SqlDbType.VarChar;
                sqlParams[3] = new SqlParameter("@phoneNo", phoneNo);
                sqlParams[3].SqlDbType = SqlDbType.VarChar;
                sqlParams[4] = new SqlParameter("@deptId", deptId);
                sqlParams[4].SqlDbType = SqlDbType.VarChar;
                sqlParams[5] = new SqlParameter("@education", education);
                sqlParams[5].SqlDbType = SqlDbType.VarChar;
                sqlParams[6] = new SqlParameter("@exp", yrsofExp);
                sqlParams[6].SqlDbType = SqlDbType.VarChar;
                sqlParams[7] = new SqlParameter("@state", state);
                sqlParams[7].SqlDbType = SqlDbType.VarChar;

                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "AddPhysicianDetails", sqlParams);
                return rowCount;
         
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region "Update Details"
        public int UpdatePhysicianDetails(string phyId, string email, string phoneNo, string yrsOfExp)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[6];
                sqlParams[0] = new SqlParameter("@phyId", phyId);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;
                sqlParams[1] = new SqlParameter("@email", email);
                sqlParams[1].SqlDbType = SqlDbType.VarChar;
                sqlParams[2] = new SqlParameter("@phoneNo", phoneNo);
                sqlParams[2].SqlDbType = SqlDbType.VarChar;
                sqlParams[3] = new SqlParameter("@exp", yrsOfExp);
                sqlParams[3].SqlDbType = SqlDbType.VarChar;


                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "UpdatePhysicianDetails", sqlParams);
                return rowCount;

            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region "Delete Details"
        public int DeletePhysicianDetails(string phyId)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@physicianId", phyId);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;

                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "DeletePhysicianDetails", sqlParams);
                return rowCount;

            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

    }
}
