﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using healthCareSystem.common;
using System.Data.SqlClient;

namespace healthCareSystem.data
{
  public class dalDepartmentDetails
  {
      #region "Get Department Details"
      public DataSet GetDepartmentDetails()
      {
          try
          {
              DataSet ds = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetDepartmentDetails");
              return ds;
          }
          catch (Exception)
          {

              throw;
          }
      }
      #endregion


      #region "Add Department Details"
      public int AddDepartmentDetails(string deptName)
      {
          try
          {
              SqlParameter[] sqlParams = new SqlParameter[1];
              sqlParams[0] = new SqlParameter("@deptName", deptName);
              sqlParams[0].SqlDbType = SqlDbType.VarChar;

              int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "AddDepartmentDetails", sqlParams);
              return rowCount;

          }
          catch (Exception)
          {

              throw;
          }
      }
      #endregion

      #region "Delete Department Details"
      public int DeleteDepartmentDetails(string deptId)
      {
          try
          {
              SqlParameter[] sqlParams = new SqlParameter[1];
              sqlParams[0] = new SqlParameter("@DeptId", deptId);
              sqlParams[0].SqlDbType = SqlDbType.VarChar;

              int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "DeleteDepartmentDetails", sqlParams);
              return rowCount;

          }
          catch (Exception)
          {

              throw;
          }
      }
      #endregion
  }
}
