﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports healthCareSystem.business
Imports System.Data
Imports System.Configuration
Imports System.Web.Security
Imports System.Security.Principal
Imports System.Threading

Namespace healthCareSystem.Admin
    Partial Public Class addPhysician
        Inherits System.Web.UI.Page

        ' Object initialization
#Region "Object Initialization"

        Private businessObj As New businessPhysician()
        Private stateObj As New businessState()
#End Region

        ' Variable Declaration
#Region "Variable Declaration"
        Private physicianDs, departmentDataSet As DataSet
        Private getRowCount As Integer
#End Region

        ' Page load
        Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
            If Not Page.IsPostBack Then
                BindPhysicianDetails()
                messageLabel.Text = String.Empty
                BindDepartmentDetails()
                BindStateDetails()
            End If
            Me.firstNameTextBox.Focus()
        End Sub

        ' Casestudy Implementation here
        Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
            'base.VerifyRenderingInServerForm(control);
        End Sub

        ' Fetch Employee data from DB and display in the grid
#Region "Bind Grid Details"
        Public Sub BindPhysicianDetails()

            physicianDs = businessObj.GetPhysicianDetails()
            PhysicianGridView.DataSource = physicianDs
            PhysicianGridView.DataBind()

        End Sub
#End Region

        ' Fetch DEpartment data from DB and display in the grid
#Region "Bind Department Details"
        Public Sub BindDepartmentDetails()
            departmentDataSet = businessObj.GetDepartmentDetails()

            departmentDropdownList.DataTextField = departmentDataSet.Tables(0).Columns("DeptName").ToString()
            departmentDropdownList.DataValueField = departmentDataSet.Tables(0).Columns("DeptId").ToString()

            departmentDropdownList.DataSource = departmentDataSet.Tables(0)
            departmentDropdownList.DataBind()

            departmentDropdownList.Items.Insert(0, New ListItem(" <-- Select -->", "0"))

        End Sub
#End Region

#Region "Bind State Details"
        Public Sub BindStateDetails()
            Dim ds As DataSet = stateObj.GetStateDetails()

            stateDropDownList.DataTextField = ds.Tables(0).Columns("Name").ToString()
            stateDropDownList.DataValueField = ds.Tables(0).Columns("StateId").ToString()

            stateDropDownList.DataSource = ds.Tables(0)
            stateDropDownList.DataBind()

            stateDropDownList.Items.Insert(0, New ListItem(" <-- Select -->", "0"))
        End Sub
#End Region


        Protected Sub addButton_Click(ByVal sender As Object, ByVal e As EventArgs) 'string education, string yrsofExp, string state

            If departmentDropdownList.SelectedIndex > 0 Then
                getRowCount = businessObj.AddPhysicianDetails(firstNameTextBox.Text.Trim(), lastNameTextBox.Text.Trim(), emailTextBox.Text.Trim(), phoneTextBox.Text.Trim(), departmentDropdownList.Text, eduDropDownList.SelectedValue.ToString(), expTextBox.Text.Trim(), stateDropDownList.Text)
                PhysicianGridView.EditIndex = -1
                PhysicianGridView.ShowFooter = False
                BindPhysicianDetails()
                firstNameTextBox.Text = String.Empty
                lastNameTextBox.Text = String.Empty
                emailTextBox.Text = String.Empty
                phoneTextBox.Text = String.Empty
                messageLabel.Text = "Physician Details added successfully!..."
            Else
                dropdownlistMessageLabel.Text = "Please select valid department name and proceed."
            End If
        End Sub

        Protected Sub PhysicianGridView_RowCancelingEdit(ByVal sender As Object, ByVal e As GridViewCancelEditEventArgs)
            PhysicianGridView.EditIndex = -1
            BindPhysicianDetails()
            messageLabel.Text = String.Empty
        End Sub

        Protected Sub PhysicianGridView_RowDeleting(ByVal sender As Object, ByVal e As GridViewDeleteEventArgs)
            Dim _row As GridViewRow = PhysicianGridView.Rows(e.RowIndex)
            Dim lblPhyId As Label = CType(_row.FindControl("lblPhyId"), Label)

            getRowCount = businessObj.DeletePhysicianDetails(lblPhyId.Text.Trim())
            PhysicianGridView.EditIndex = -1
            BindPhysicianDetails()
            messageLabel.Text = "Physician Details deleted successfully!..."
        End Sub

        Protected Sub PhysicianGridView_RowEditing(ByVal sender As Object, ByVal e As GridViewEditEventArgs)
            PhysicianGridView.EditIndex = e.NewEditIndex
            BindPhysicianDetails()
            messageLabel.Text = String.Empty
        End Sub

        Protected Sub PhysicianGridView_RowUpdating(ByVal sender As Object, ByVal e As GridViewUpdateEventArgs)
            Dim _row As GridViewRow = PhysicianGridView.Rows(e.RowIndex)
            Dim emailTextBox As TextBox = CType(_row.FindControl("emailTextBox"), TextBox)
            Dim phoneTextBox As TextBox = CType(_row.FindControl("phoneTextBox"), TextBox)
            Dim yrsTextbox As TextBox = CType(_row.FindControl("yrsTextbox"), TextBox)
            Dim lblPhyId As Label = CType(_row.FindControl("lblPhyId"), Label)

            getRowCount = businessObj.UpdatePhysicianDetails(lblPhyId.Text.Trim(), emailTextBox.Text.Trim(), phoneTextBox.Text.Trim(), yrsTextbox.Text.Trim())
            PhysicianGridView.EditIndex = -1
            BindPhysicianDetails()
            messageLabel.Text = "Physician Details updated successfully!..."
        End Sub



    End Class
End Namespace
