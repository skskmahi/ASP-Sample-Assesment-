﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports healthCareSystem.business
Imports System.Configuration

Namespace healthCareSystem.Admin
	Partial Public Class addState
		Inherits System.Web.UI.Page

		' Object initialization
		#region "Object Initialization"
		Private businessObj As New businessState()
		#End Region

		' Variable Declaration
		#region "Variable Declaration"
		Private stateDs As DataSet
		#End Region

		' Page load
		#region "Page Load"
		Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
			  If Not Page.IsPostBack Then
					BindData()
					messageLabel.Text = String.Empty
			  End If
		End Sub

		#End Region ' "Page Load"

		' Fetch state data from DB and display in the grid
		#region "Bind Grid Details"
		Public Sub BindData()
			stateDs = New DataSet()
			stateDs = businessObj.GetStateDetails()
			stateGridView.DataSource = stateDs
			stateGridView.DataBind()
		End Sub
		#End Region



		' Update DB with the new state details and display the grid
		Protected Sub addStateButton_Click(ByVal sender As Object, ByVal e As EventArgs)
			'Please do the casestudy implementation here
		End Sub



	End Class
End Namespace
