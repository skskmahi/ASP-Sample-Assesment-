﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports healthCareSystem.business
Imports System.Data
Imports System.Configuration

Namespace healthCareSystem.Admin
	Partial Public Class searchPhysician
		Inherits System.Web.UI.Page

		' Object initialization
		#region "Object Initialization"
		Private businessObj As New businessPhysician()
		#End Region

		' Variable Declaration
		#region "Variable Declaration"
		Private physicianDs, departmentDs As DataSet
		#End Region

		' Page load
		Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
			  If Not Page.IsPostBack Then
					messageLabel.Text = String.Empty
					searchResultsGridView.DataSource = Nothing
					searchResultsGridView.DataBind()
					BindDepartmentDetails()
			  End If
		End Sub


		' Fetch department data from DB and display in the grid
		#region "Bind Department Details"
		Public Sub BindDepartmentDetails()
			departmentDs = New DataSet()
			departmentDs = businessObj.GetDepartmentDetails()


			departmentDropdownList.DataTextField = departmentDs.Tables(0).Columns("DeptName").ToString()
			departmentDropdownList.DataValueField = departmentDs.Tables(0).Columns("DeptId").ToString()

			departmentDropdownList.DataSource = departmentDs.Tables(0)
			departmentDropdownList.DataBind()

			departmentDropdownList.Items.Insert(0, New ListItem(" <-- Select -->", "0"))
		End Sub
		#End Region

		Protected Sub searchButton_Click(ByVal sender As Object, ByVal e As EventArgs)
			Dim firstname As String = nameTextBox.Text.Trim()
			If departmentDropdownList.SelectedIndex = 0 AndAlso firstname = String.Empty Then
				messageLabel.Text = "Please enter some search criteria and proceed !"
			Else

				If firstname = String.Empty Then
					firstname = "#"
				End If

				physicianDs = businessObj.SearchPhysicianDetails(firstname, departmentDropdownList.SelectedValue)
				If physicianDs.Tables(0).Rows.Count > 0 Then
				messageLabel.Text = ""
				searchResultsGridView.DataSource = physicianDs
				searchResultsGridView.DataBind()

				Else
					searchResultsGridView.DataSource = Nothing
					searchResultsGridView.DataBind()

				messageLabel.Text = "No records returned for given search criteria."
				nameTextBox.Text = String.Empty
				departmentDropdownList.SelectedIndex = 0
				End If
			End If
		End Sub


	End Class
End Namespace