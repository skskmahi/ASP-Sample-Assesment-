﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.SessionState
Imports System.Security.Principal
Imports System.Web.Routing
Imports log4net

Namespace healthCareSystem
	Partial Public Class [Global]
		Inherits System.Web.HttpApplication

	   Private Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
			' Code that runs on application startup
			Dim l4net As String = Server.MapPath("~/log4net.config")
			log4net.Config.XmlConfigurator.ConfigureAndWatch(New System.IO.FileInfo(l4net))


			URLRoutes.RegisterRoutes(RouteTable.Routes)
	   End Sub

		Private Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
			'  Code that runs on application shutdown
		End Sub

		Private Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
			Dim lastException As Exception = Server.GetLastError().GetBaseException()
			Dim logger As ILog = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)
			logger.Fatal("Fatal Error occurred in the HealthCare System." & lastException.Message)
		End Sub

		Protected Sub Application_OnPostAuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
			Try
				If HttpContext.Current.User IsNot Nothing Then
					If HttpContext.Current.User.Identity.IsAuthenticated Then
						If TypeOf HttpContext.Current.User.Identity Is FormsIdentity Then
'INSTANT VB NOTE: The variable id was renamed since Visual Basic does not handle local variables named the same as class members well:
							Dim id_Renamed As FormsIdentity = DirectCast(HttpContext.Current.User.Identity, FormsIdentity)
							Dim ticket As FormsAuthenticationTicket = id_Renamed.Ticket
							Dim userData As String = ticket.UserData
							Dim roles() As String = userData.Split(","c)
							HttpContext.Current.User = New GenericPrincipal(id_Renamed, roles)
						End If
					End If
				End If
			Catch ex As Exception
				Dim lastException As Exception = Server.GetLastError().GetBaseException()
				Dim logger As ILog = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)
				logger.Fatal("Fatal Error occurred in the HealthCare System." & lastException.Message)
				Response.Redirect("~/ErrorPage/customErrorPage.aspx", False)
			End Try
		End Sub


	   'protected void Application_AuthenticateRequest(Object sender, EventArgs e)
	   ' {

	   ' }

		Private Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
			' Code that runs when a new session is started

		End Sub

		Private Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
			' Code that runs when a session ends. 
			' Note: The Session_End event is raised only when the sessionstate mode
			' is set to InProc in the Web.config file. If session mode is set to StateServer 
			' or SQLServer, the event is not raised.

		End Sub
	End Class


	Public Class URLRoutes
		Public Shared Sub RegisterRoutes(ByVal routes As RouteCollection)
			'routes.MapPageRoute("AddPhysician", "AddDoctor", "~/Admin/addPhysician.aspx");
			'routes.MapPageRoute("AddDepartment", "AddDepartment", "~/Admin/addDepartment.aspx");
			'routes.MapPageRoute("SearchPhysician", "Search", "~/Admin/searchPhysician.aspx");

			routes.MapPageRoute("Login", "LoginPage", "~/Login/loginForm.aspx")
		End Sub
	End Class

End Namespace
