﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data.Linq.Mapping

Namespace healthCareSystem.Login
	<Table(Name := "UserRoles")> _
	Public Class UserObj
		<Column(IsPrimaryKey:=True, IsDbGenerated := True, AutoSync:=AutoSync.OnInsert)> _
		Public Property UserId() As Integer
		<Column> _
		Public Property UserName() As String
		<Column> _
		Public Property Password() As String
		<Column> _
		Public Property RoleName() As String
	End Class
End Namespace