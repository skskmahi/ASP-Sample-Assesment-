﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data
Imports System.Data.Linq
Imports System.Configuration

Namespace healthCareSystem.Login
	Public Class User
		Private usersTable As Table(Of UserObj)
		Private context As DataContext

		Public Sub New()
			Dim connectionString As String = ConfigurationManager.ConnectionStrings("DbConnection").ConnectionString
			context = New DataContext(connectionString)
			usersTable = context.GetTable(Of UserObj)()
		End Sub

		Public Function GetUserObjByUserName(ByVal userName As String, ByVal passWord As String) As UserObj
			Dim user As UserObj = usersTable.FirstOrDefault(Function(u) u.UserName = userName AndAlso u.Password = passWord)
			Return user
		End Function

		Public Function GetUserObjByUserName(ByVal userName As String) As UserObj
			Dim user As UserObj = usersTable.SingleOrDefault(Function(u) u.UserName = userName)
			Return user
		End Function

		Public Function GetAllUsers() As IEnumerable(Of UserObj)
			Return usersTable.AsEnumerable()
		End Function

		Public Function IsUserInRole(ByVal userName As String, ByVal userRole As String) As Boolean
			Dim user = usersTable.SingleOrDefault(Function(u) u.UserName = userName)
			If user Is Nothing Then
				Return False
			End If
			If user.RoleName = userRole Then
				Return True
			Else
				Return False
			End If
		End Function

		Public Function GetUserRoles(ByVal userName As String) As String()
			Dim user = usersTable.SingleOrDefault(Function(u) u.UserName = userName)
			If user Is Nothing Then
				Return New String() { }
			End If
			If user.RoleName Is Nothing Then
				Return New String() { }
			Else
				Dim roleNames(4) As String
				roleNames(0) = user.RoleName
				Return roleNames
			End If

		End Function

	End Class
End Namespace