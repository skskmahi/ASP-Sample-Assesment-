﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports healthCareSystem.business
Imports System.Web.Security
Imports System.Configuration


Namespace healthCareSystem.Login
	Partial Public Class loginForm
		Inherits System.Web.UI.Page

		' Object initialization
		#region "Object Initialization"
		Private businessObjEmp As New businessPhysician()
		Private businessObj As New businessDepartmentDetails()
		#End Region

		' Page load
		Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)

		End Sub

		' Authenticate User
		Protected Sub LoginControl_Authenticate(ByVal sender As Object, ByVal e As AuthenticateEventArgs)
			Try

				If True Then ' Please do the implementation for Authentication
					Dim roleName As String = String.Empty ' Please do the implementation for Authorization.
					SetFormAuthenticationTicket(LoginControl.UserName, roleName)
				End If
			Catch ex As Exception
				   Session("CurrentError") = "Error occured during Authentication for the user " & LoginControl.UserName.ToString()
			End Try
		End Sub


		Public Sub SetFormAuthenticationTicket(ByVal userName As String, ByVal roleName As String)
			FormsAuthentication.Initialize()
			Dim Authticket As New FormsAuthenticationTicket(1, userName, Date.Now, Date.Now.AddMinutes(30), False, roleName, FormsAuthentication.FormsCookiePath) ' Do not remember me

			Dim hash As String = FormsAuthentication.Encrypt(Authticket)

			Dim Authcookie As New HttpCookie(FormsAuthentication.FormsCookieName, hash)
			If Authticket.IsPersistent Then
				Authcookie.Expires = Authticket.Expiration
			End If
			Response.Cookies.Add(Authcookie)
		End Sub

	End Class
End Namespace