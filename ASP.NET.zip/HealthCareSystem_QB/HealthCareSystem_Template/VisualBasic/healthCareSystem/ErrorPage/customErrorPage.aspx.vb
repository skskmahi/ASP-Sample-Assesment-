﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.Routing

Namespace healthCareSystem.ErrorPage
	Partial Public Class customErrorPage
		Inherits System.Web.UI.Page

		Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
			Dim parameters = New RouteValueDictionary From { }
			Dim vpd As VirtualPathData = RouteTable.Routes.GetVirtualPath(Nothing, "Login", parameters)
			loginPageHyperLink.NavigateUrl = vpd.VirtualPath
		End Sub
	End Class
End Namespace