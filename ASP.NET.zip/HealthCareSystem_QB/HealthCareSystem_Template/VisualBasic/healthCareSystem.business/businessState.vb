﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data
Imports healthCareSystem.data

Namespace healthCareSystem.business
	Public Class businessState

		#region "Variable Declaration"

		Private stateDs As DataSet = Nothing
		Private getQuery As String = String.Empty

		Private dalObj As New dalState()

		#End Region

		#region "Object Initialization"
		Private rowCount As Integer = 0
		#End Region

		#region "Get Details"
		Public Function GetStateDetails() As DataSet
			stateDs = dalObj.GetStateDetails()
			Return stateDs

		End Function
		#End Region

		#region "Add Details"
		Public Function AddStateDetails(ByVal stateName As String) As Integer
			Try
				Dim rowCount As Integer = 0
				'Please do the casestudy implementation here
				Return rowCount
			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region
	End Class
End Namespace
