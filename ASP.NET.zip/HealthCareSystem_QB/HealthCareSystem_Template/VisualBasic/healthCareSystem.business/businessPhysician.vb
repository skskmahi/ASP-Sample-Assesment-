﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data.SqlClient
Imports healthCareSystem.data
Imports System.Data


Namespace healthCareSystem.business
   Public Class businessPhysician
		#region "Variable Declaration"
			Private getQuery As String = String.Empty
			Private rowCount As Integer = 0
			Private dalDepartmentObj As New dalDepartmentDetails()
			Private dalPhysicianObj As New dalPhysicianDetails()
		#End Region

		#region "Get Drop Downlist Bind Details"
		Public Function GetDepartmentDetails() As DataSet

			Dim departmentDataSet As DataSet = dalDepartmentObj.GetDepartmentDetails()
			Return departmentDataSet

		End Function
		#End Region

		#region "Get Physician Details"
		Public Function GetPhysicianDetails() As DataSet
			Dim physicianDs As DataSet = dalPhysicianObj.GetPhysicianDetails()
			Return physicianDs

		End Function

		#End Region

		#region "Search Physician Details"
		Public Function SearchPhysicianDetails(ByVal firstName As String, ByVal deptId As String) As DataSet
			Dim physicianDs As DataSet = dalPhysicianObj.SearchPhysicianDetails(firstName, deptId)
			Return physicianDs

		End Function

		#End Region


		#region "Add Details"
		Public Function AddPhysicianDetails(ByVal firstName As String, ByVal lastName As String, ByVal email As String, ByVal phoneNo As String, ByVal deptId As String, ByVal education As String, ByVal yrsofExp As String, ByVal state As String) As Integer
			Try
				rowCount = dalPhysicianObj.AddPhysicianDetails(firstName, lastName, email, phoneNo, deptId, education, yrsofExp, state)
				Return rowCount
			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

		#region "Update Details"
		Public Function UpdatePhysicianDetails(ByVal phyId As String, ByVal email As String, ByVal phoneNo As String, ByVal yrsOfExp As String) As Integer
			Try
				rowCount = dalPhysicianObj.UpdatePhysicianDetails(phyId, email, phoneNo, yrsOfExp)
				Return rowCount
			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

		#region "Delete Details"
		Public Function DeletePhysicianDetails(ByVal phyId As String) As Integer
			Try
				rowCount = dalPhysicianObj.DeletePhysicianDetails(phyId)
				Return rowCount
			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

   End Class
End Namespace
