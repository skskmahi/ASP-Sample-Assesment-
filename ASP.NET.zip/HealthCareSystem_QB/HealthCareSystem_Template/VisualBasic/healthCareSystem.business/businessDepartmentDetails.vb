﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports healthCareSystem.data


Namespace healthCareSystem.business
	Public Class businessDepartmentDetails
		#region "Variable Declaration"

		Private departmentDataSet As DataSet = Nothing
		Private getQuery As String = String.Empty

		Private dalDepartmentObj As New dalDepartmentDetails()

		#End Region

		#region "Object Initialization"
		Private rowCount As Integer = 0
		#End Region

		#region "Get Details"
		Public Function GetDepartmentDetails() As DataSet
			departmentDataSet = dalDepartmentObj.GetDepartmentDetails()
			Return departmentDataSet

		End Function
		#End Region

		#region "Add Details"
		Public Function AddDepartmentDetails(ByVal deptName As String) As Integer
			Try
				rowCount = dalDepartmentObj.AddDepartmentDetails(deptName)
				Return rowCount
			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

		#region "Delete Details"
		Public Function DeleteDepartmentDetails(ByVal deptId As String) As Integer
			Try
				rowCount = dalDepartmentObj.DeleteDepartmentDetails(deptId)
				Return rowCount
			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

	End Class
End Namespace
