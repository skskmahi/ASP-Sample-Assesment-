﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data
Imports System.Web
Imports System.Data.SqlClient
Imports healthCareSystem.common

Namespace healthCareSystem.data
	Public Class dalPhysicianDetails
		#region "Get Physician Details"
		Public Function GetPhysicianDetails() As DataSet
			Try
				Dim ds As DataSet = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetPhysicianDetails")
				Return ds
			Catch ex As Exception

				Throw ex
			End Try
		End Function
		#End Region

		#region "Get Physician Details"
		Public Function SearchPhysicianDetails(ByVal firstName As String, ByVal deptId As String) As DataSet
			Try
				Dim sqlParams(1) As SqlParameter
				sqlParams(0) = New SqlParameter("@firstName", firstName)
				sqlParams(0).SqlDbType = SqlDbType.VarChar
				sqlParams(1) = New SqlParameter("@deptid", deptId)
				sqlParams(1).SqlDbType = SqlDbType.VarChar
				Dim ds As DataSet = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "SearchPhysicianDetails", sqlParams)
				Return ds
			Catch ex As Exception

				Throw ex
			End Try
		End Function
		#End Region


		#region "Add Physician Details"
		Public Function AddPhysicianDetails(ByVal firstName As String, ByVal lastName As String, ByVal email As String, ByVal phoneNo As String, ByVal deptId As String, ByVal education As String, ByVal yrsofExp As String, ByVal state As String) As Integer
			Try
				Dim sqlParams(7) As SqlParameter
				sqlParams(0) = New SqlParameter("@firstName", firstName)
				sqlParams(0).SqlDbType = SqlDbType.VarChar
				sqlParams(1) = New SqlParameter("@lastName", lastName)
				sqlParams(1).SqlDbType = SqlDbType.VarChar
				sqlParams(2) = New SqlParameter("@email", email)
				sqlParams(2).SqlDbType = SqlDbType.VarChar
				sqlParams(3) = New SqlParameter("@phoneNo", phoneNo)
				sqlParams(3).SqlDbType = SqlDbType.VarChar
				sqlParams(4) = New SqlParameter("@deptId", deptId)
				sqlParams(4).SqlDbType = SqlDbType.VarChar
				sqlParams(5) = New SqlParameter("@education", education)
				sqlParams(5).SqlDbType = SqlDbType.VarChar
				sqlParams(6) = New SqlParameter("@exp", yrsofExp)
				sqlParams(6).SqlDbType = SqlDbType.VarChar
				sqlParams(7) = New SqlParameter("@state", state)
				sqlParams(7).SqlDbType = SqlDbType.VarChar

				Dim rowCount As Integer = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "AddPhysicianDetails", sqlParams)
				Return rowCount

			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

		#region "Update Details"
		Public Function UpdatePhysicianDetails(ByVal phyId As String, ByVal email As String, ByVal phoneNo As String, ByVal yrsOfExp As String) As Integer
			Try
				Dim sqlParams(5) As SqlParameter
				sqlParams(0) = New SqlParameter("@phyId", phyId)
				sqlParams(0).SqlDbType = SqlDbType.VarChar
				sqlParams(1) = New SqlParameter("@email", email)
				sqlParams(1).SqlDbType = SqlDbType.VarChar
				sqlParams(2) = New SqlParameter("@phoneNo", phoneNo)
				sqlParams(2).SqlDbType = SqlDbType.VarChar
				sqlParams(3) = New SqlParameter("@exp", yrsOfExp)
				sqlParams(3).SqlDbType = SqlDbType.VarChar


				Dim rowCount As Integer = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "UpdatePhysicianDetails", sqlParams)
				Return rowCount

			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

		#region "Delete Details"
		Public Function DeletePhysicianDetails(ByVal phyId As String) As Integer
			Try
				Dim sqlParams(0) As SqlParameter
				sqlParams(0) = New SqlParameter("@physicianId", phyId)
				sqlParams(0).SqlDbType = SqlDbType.VarChar

				Dim rowCount As Integer = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "DeletePhysicianDetails", sqlParams)
				Return rowCount

			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

	End Class
End Namespace
