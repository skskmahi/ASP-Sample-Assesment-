﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data
Imports healthCareSystem.common
Imports System.Data.SqlClient

Namespace healthCareSystem.data
  Public Class dalDepartmentDetails
	  #region "Get Department Details"
	  Public Function GetDepartmentDetails() As DataSet
		  Try
			  Dim ds As DataSet = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetDepartmentDetails")
			  Return ds
		  Catch e1 As Exception

			  Throw
		  End Try
	  End Function
	  #End Region


	  #region "Add Department Details"
	  Public Function AddDepartmentDetails(ByVal deptName As String) As Integer
		  Try
			  Dim sqlParams(0) As SqlParameter
			  sqlParams(0) = New SqlParameter("@deptName", deptName)
			  sqlParams(0).SqlDbType = SqlDbType.VarChar

			  Dim rowCount As Integer = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "AddDepartmentDetails", sqlParams)
			  Return rowCount

		  Catch e1 As Exception

			  Throw
		  End Try
	  End Function
	  #End Region

	  #region "Delete Department Details"
	  Public Function DeleteDepartmentDetails(ByVal deptId As String) As Integer
		  Try
			  Dim sqlParams(0) As SqlParameter
			  sqlParams(0) = New SqlParameter("@DeptId", deptId)
			  sqlParams(0).SqlDbType = SqlDbType.VarChar

			  Dim rowCount As Integer = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "DeleteDepartmentDetails", sqlParams)
			  Return rowCount

		  Catch e1 As Exception

			  Throw
		  End Try
	  End Function
	  #End Region
  End Class
End Namespace
