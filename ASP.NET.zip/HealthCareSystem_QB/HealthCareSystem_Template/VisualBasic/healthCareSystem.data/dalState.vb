﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data
Imports healthCareSystem.common
Imports System.Data.SqlClient

Namespace healthCareSystem.data
   Public Class dalState

		#region "Get State Details"
		Public Function GetStateDetails() As DataSet
			Try
				Dim ds As DataSet = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetStateDetails")
				Return ds
			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region

		#region "Add State Details"
		Public Function AddStateDetails(ByVal stateName As String) As Integer
			Try
				Dim rowCount As Integer = 0
			   'Please do the casestudy implementation here
				Return rowCount

			Catch e1 As Exception

				Throw
			End Try
		End Function
		#End Region
   End Class
End Namespace
